// 패키지 선언
package com.springboot.react.controller;

// 필요한 클래스와 인터페이스를 임포트합니다.
import com.springboot.react.entity.Post;
import com.springboot.react.service.PostService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

// @RestController 어노테이션은 이 클래스가 REST 컨트롤러임을 나타내며, 자동으로 클래스 내의 모든 메소드의 반환값을 
// HTTP 응답 본문으로 사용합니다.
@RestController
// @RequestMapping 어노테이션은 이 컨트롤러의 모든 메소드가 처리할 기본 URL 경로를 설정합니다.
@RequestMapping("/api/posts")
public class PostController {

    // PostService의 인스턴스를 final로 선언하여 변경 불가능하게 만듭니다.
    private final PostService postService;

    // @Autowired 어노테이션을 통해 생성자 주입을 사용하여 PostService 인스턴스를 자동으로 주입받습니다.
    @Autowired
    public PostController(PostService postService) {
        this.postService = postService;
    }

    // ID를 기준으로 게시글을 조회하는 메소드
    @GetMapping("/{id}")
    public ResponseEntity<Post> getPostById(@PathVariable Long id) {
        // PostService를 사용하여 id에 해당하는 Post를 조회합니다.
        Optional<Post> post = postService.findById(id);
        // 조회된 Post가 존재하면 상태 코드 200(OK)과 함께 반환하고, 그렇지 않으면 404(Not Found)를 반환합니다.
        return post.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    // 모든 게시글을 조회하는 메소드
    @GetMapping
    public List<Post> getAllPosts() {
        // PostService를 통해 모든 Post를 리스트로 반환합니다.
        return postService.findAll();
    }
    
    // ID를 기준으로 게시글을 수정하는 메소드
    @PutMapping("/{id}")
    public ResponseEntity<Post> updatePost(@PathVariable Long id, @RequestBody Post postDetails) {
        // PostService를 사용하여 게시글을 업데이트하고 결과를 반환합니다.
        Post updatedPost = postService.updatePost(id, postDetails);
        return ResponseEntity.ok(updatedPost);
    }
    
    // ID를 기준으로 게시글을 삭제하는 메소드
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deletePost(@PathVariable Long id) {
        // PostService를 사용하여 id에 해당하는 Post를 삭제합니다.
        postService.deletePost(id);
        // 삭제 성공 시 상태 코드 200(OK)를 반환합니다.
        return ResponseEntity.ok().build();
    }
    
    // @PostMapping은 HTTP POST 요청을 처리하는 메소드임을 나타내는 어노테이션입니다.
    // 메소드 위에 별도의 경로를 지정하지 않았기 때문에, 클래스 레벨의 @RequestMapping의 경로를 사용합니다.
    @PostMapping
    public Post createPost(@RequestBody Post post) {
        // @RequestBody 어노테이션은 HTTP 요청의 본문을 Java 객체로 매핑합니다.
        // 이 메소드는 클라이언트로부터 받은 Post 객체를 postService를 통해 저장하고,
        // 저장된 Post 객체를 반환합니다.
        return postService.savePost(post);
    }
}
