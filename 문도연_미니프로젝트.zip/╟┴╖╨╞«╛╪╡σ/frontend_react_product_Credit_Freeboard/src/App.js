import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import ProductList from './components/ProductList';
import ProductDetail from './components/ProductDetail';
import CartPage from './components/CartPage';
import Navigation from './components/Navigation';
import ProductFormCreate from './components/ProductFormCreate';
import ProductFormEdit from './components/ProductFormEdit';
import { CartProvider } from './components/CartContext'; // CartContext 임포트
import Payment from './components/Payment';
import PaymentSuccess from './components/PaymentSuccess';
import PostList from './components/PostList';
import PostDetail from './components/PostDetail';
import PostEdit from './components/PostEdit';
import CreatePost from './components/CreatePost';
import Header from './components/Header';
import Footer from './components/Footer';
import Main from './components/Main';
import AddrDaumKakao02 from './components/AddrDaumKakao02';
import './App.css'; // App.css 임포트

const App = () => {
  return (
    <CartProvider>
      <Router>
        <div className="app-container">
          <div className="navbar">
            <Navigation /> {/* 네비게이션 추가 */}
          </div>
          <div className="content">
            <Switch>
              <Route path="/posts" component={PostList} exact={true} />
              <Route path="/product" component={ProductList} />
              <Route path="/" component={Main} exact={true} />
              <Route path="/products/:id" component={ProductDetail} />
              <Route path="/add" component={ProductFormCreate} />
              <Route path="/edit/:id" component={ProductFormEdit} />
              <Route path="/payment" component={Payment} />
              <Route path="/cart" component={CartPage} />
              <Route path="/paymentSuccess" component={PaymentSuccess} />
              <Route path="/posts/:boardNumber" component={PostDetail} />
              <Route path="/edit/:boardNumber" component={PostEdit} />
              <Route path="/create" component={CreatePost} />
              <Route path="/daum_kakao_addr_02" component={AddrDaumKakao02} />
            </Switch>
          </div>
          <Footer /> {/* 푸터 추가 */}
        </div>
      </Router>
    </CartProvider>
  );
};

export default App;
