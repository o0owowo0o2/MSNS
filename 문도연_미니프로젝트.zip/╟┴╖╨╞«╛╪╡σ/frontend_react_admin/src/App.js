import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.css';
import LandingPage from './components/LandingPage';
import About from './components/About';
import PostList from './components/PostList';
import EmpBoardInsert from './components/EmpBoardInsert';
import PostDetail from './components/PostDetail';
import PostEdit from './components/PostEdit';
import PostDelete from './components/PostDelete';
import Footer from './components/Footer';
import Header from './components/Header';
import MemberMain from './components/MemberMain';
import LoginMain from './components/LoginMain';
import ProductDetail from './components/ProductDetail';

function App() {
  return (
    <Router>
      <div>
        <Switch>
          <Route path="/" exact component={LandingPage} />
          <>
            <Header />
            <Switch>
            <Route path="/about" component={About} />
            <Route path="/postlist" component={PostList} />
            <Route path="/register" component={EmpBoardInsert} />
            <Route path="/membermain" component={MemberMain} />
            <Route path="/loginmain" component={LoginMain} />
            <Route path="/productdetail" component={ProductDetail} />

          
            <Route path="/posts/:boardNumber" component={PostDetail} />
            <Route path="/edit/:boardNumber" component={PostEdit} />
            <Route path="/delete/:boardNumber" component={PostDelete} />

            
            </Switch>
            <Footer />
          </>
        </Switch>
      </div>
    </Router>
  );
}

export default App;
