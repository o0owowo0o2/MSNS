// rsf
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useParams, useHistory } from 'react-router-dom';
import "../css/postedit.css";
function PostEdit() {

    const[post, setPost] = useState({boardTitle:'', boardContents:'', boardWriter:'' });
    const{boardNumber} = useParams();
    const history = useHistory();

    useEffect(()=> {
        const fetchPost = async() => {
            try{
                // 게시글의 상세 정보를 서버로부터 비동기적으로 요청합니다.
                const response = await axios.get(`http://localhost:9008/api/posts/${boardNumber}`);
              // 위에서 얻은 응답 데이터로 post 상태를 업데이트합니다.
                setPost(response.data);
            } catch(error){
                console.log(error);
                alert('에러가 발생했습니다!');
            }
        };
        fetchPost(); // fetchPost 함수를 호출하여 실행합니다.
        // boardNumber가 변경될 때마다 useEffect가 다시 실행됩니다.
    }, [boardNumber]); 

    // 입력 필드의 변경을 처리하는 함수를 만들어줍니다.
    const handleChange = (e) => {
        // 이벤트 발생한 요소의 name과 value를 추출합니다.
        const {name, value} = e.target;        
        // 기존 상태에 변경된 값을 반영합니다.
        setPost(prev => ({
            ...prev,
            [name]: value
            }));
    };

    // 게시글 수정 요청을 처리하는 함수를 만들어줍니다.
    const handleUpdate = async() => {
        try{
            // 작성자 정보(boardWriter)는 수정에서 제외하고
            // 업데이트 데이터를 준비합니다.
            const {boardWriter, ...updateData} = post;
            // 수정된 데이터를 서버에 PUT 요청으로 전송합니다.
            await axios.put(`http://localhost:9008/api/posts/${boardNumber}`, updateData);
            alert('게시글이 수정되었습니다!'); // 게시글수정 성공 알림
            history.push('/postlist'); // 메인 페이지로 이동 처리함
        } catch(error){
            console.error("게시글 수정 실패", error);
        }
    };

    // 수정을 취소하고 이전 페이지로 돌아가는 함수입니다.
    const handleCancel = () => {
        history.goBack(); // 브라우저의 이전 페이지로 이동합니다.
    };

    // 글목록으로 이동하는 함수
    const goToPostList = () => {
        history.push('/postlist'); // 게시글목록으로 이동합니다.
    };

    // 글수정 이동하는 함수
    const goToPostEdit = () => {
        history.push(`/edit/${post.boardNumber}`); // 게시글목록으로 이동합니다.
    };


    return (
        <div className='inner'>
            <ul className='in'>
                
             <div className='wrapper'> <h2 className='titBr'>게시글 수정</h2></div>
                <li className='formWrp'>
                    <li className='editBrd'>
                        <li className='ConBrd'>
                            <div className='vHead'>
                                <label className='vtit'>제목</label>
                                <input type='text' name="boardTitle" value={post.boardTitle || ''} size={45} onChange={handleChange} />
                            </div> <br />
                            <div className='vBody'>
                                <label className='vCon'>내용</label>
                                <textarea name='boardContents' value={post.boardContents || ''} rows={10} cols={45} onChange={handleChange} />
                            </div> 
                            <span className='vWrt'>
                                {/* 작성자 정보는 표시만 하고 수정할 수 없게 합니다! */}
                                <label className='wriC'>작성자 : {post.boardWriter}</label>
                                <br />
                            </span>
                        </li>
                        <div className='btnW'>
                            
                                <div className='mBtn'><li onClick={handleUpdate}>수정 처리</li></div>
                                <div  className='mBtn'><li onClick={handleCancel}>수정 취소</li></div> 
                                <br />
                                <div className='mBtn'>
                                    <li onClick={goToPostList}>글목록으로 이동</li>
                                </div>
                          
                        </div>    
                    </li>
                </li>

            </ul> 
        </div>
    );
}

export default PostEdit;