// React와 React Router의 필요한 기능을 import합니다.
import React, { useState, useCallback } from 'react';
import { BrowserRouter as Router, Route } from 'react-router-dom';
import { useHistory } from 'react-router-dom';

// 주소 검색 컴포넌트를 정의합니다.
function AddressSearch() {
  // useState 훅을 사용하여 주소 검색과 관련된 상태를 관리합니다.
  const [postcode, setPostcode] = useState('');  // 우편번호
  const [roadAddress, setRoadAddress] = useState('');  // 도로명 주소
  const [jibunAddress, setJibunAddress] = useState('');  // 지번 주소
  const [detailAddress, setDetailAddress] = useState('');  // 지번 주소
  const [extraAddress, setExtraAddress] = useState('');  // 참고항목
  const [guideText, setGuideText] = useState('');  // 가이드 텍스트

  // 주소 검색 버튼 클릭 시 실행할 함수를 useCallback으로 메모이제이션합니다.
  const handleAddressSearch = useCallback(() => {
    // Daum 주소 검색 API를 호출합니다.
    new window.daum.Postcode({
      oncomplete: function(data) {
        let extraRoadAddr = '';  // 참고 항목 초기화

        // 법정동명이 있고, "동/로/가"로 끝나는 경우 참고항목에 추가합니다.
        if (data.bname !== '' && /[동|로|가]$/g.test(data.bname)) {
          extraRoadAddr += data.bname;
        }
        // 건물명이 있고 공동주택인 경우, 참고항목에 추가합니다.
        if (data.buildingName !== '' && data.apartment === 'Y') {
          extraRoadAddr += (extraRoadAddr !== '' ? ', ' + data.buildingName : data.buildingName);
        }
        // 참고항목이 있는 경우 괄호를 더하여 포맷팅합니다.
        extraRoadAddr = extraRoadAddr ? ` (${extraRoadAddr})` : '';

        // 각 상태를 업데이트합니다.
        setPostcode(data.zonecode);
        setRoadAddress(data.roadAddress);
        setJibunAddress(data.jibunAddress);
        setExtraAddress(extraRoadAddr);

        // 사용자가 자동 완성된 주소를 선택한 경우 가이드 텍스트를 설정합니다.
        if (data.autoRoadAddress) {
          const expRoadAddr = data.autoRoadAddress + extraRoadAddr;
          setGuideText(`(예상 도로명 주소: ${expRoadAddr})`);
        } else if (data.autoJibunAddress) {
          const expJibunAddr = data.autoJibunAddress;
          setGuideText(`(예상 지번 주소: ${expJibunAddr})`);
        } else {
          setGuideText('');
        }
      }
    }).open();
  }, []);

  // HTML 구조와 각 요소에 대한 데이터 바인딩을 정의합니다.
  return (
    <div>
      <input type="text" value={postcode} onChange={e => setPostcode(e.target.value)} placeholder="우편번호" readOnly />
      <button onClick={handleAddressSearch}>우편번호 찾기</button><br />
      {/* 아래에 size={45} 속성을 적용하여 장문으로 입력된 값을 볼 수 있도록 입력란을 넓혀 줍니다! */}
      <input type="text" value={roadAddress} size={45} onChange={e => setRoadAddress(e.target.value)} placeholder="도로명주소" readOnly />
      <br />
      {/* 아래에 size={45} 속성을 적용하여 장문으로 입력된 값을 볼 수 있도록 입력란을 넓혀 줍니다! */}
      <input type="text" value={jibunAddress} size={45} onChange={e => setJibunAddress(e.target.value)} placeholder="지번주소" readOnly />      
      <br />
      {/* 아래에 size={45} 속성을 적용하여 장문으로 입력된 값을 볼 수 있도록 입력란을 넓혀 줍니다! */}
      <input type="text" value={detailAddress} size={45} onChange={e => setDetailAddress(e.target.value)} placeholder="상세주소" />      
      <br />      
      {/* 아래에 size={45} 속성을 적용하여 장문으로 입력된 값을 볼 수 있도록 입력란을 넓혀 줍니다! */}
      <input type="text" value={extraAddress} size={45} onChange={e => setExtraAddress(e.target.value)} placeholder="참고항목" readOnly />
      <span style={{ color: '#999', display: guideText ? 'inline' : 'none' }}>{guideText}</span>
    </div>
  );
}

// 라우터 컴포넌트를 정의합니다. 주소 검색 컴포넌트를 "/" 경로에 연결합니다.
function AddrDaumKakao02() {

  const history = useHistory();

  // 메인으로 이동하는 함수
  const goToMain = () => {
    history.push('/'); // 메인 페이지로 이동합니다.
  };

  return (
    <Router>
      <Route path="/daum_kakao_addr_02" component={AddressSearch} />
      <div>
        <br />
        <button onClick={goToMain}>메인으로 Go!</button>
      </div>
    </Router>
  );
}

// AddrDaumKakao02 컴포넌트를 export하여 다른 파일에서 사용할 수 있게 합니다.
export default AddrDaumKakao02;
