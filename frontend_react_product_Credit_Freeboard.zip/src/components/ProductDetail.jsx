import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams, Link } from 'react-router-dom';
import { useCart } from './CartContext'; // CartContext 임포트
import '../css/ProductDetail.css'; // CSS 파일 임포트

const ProductDetail = () => {
  const [product, setProduct] = useState(null);
  const [notification, setNotification] = useState(''); // 알림 메시지 상태 추가
  const { id } = useParams();
  const { addToCart } = useCart(); // addToCart 함수 사용

  useEffect(() => {
    const fetchProduct = async () => {
      try {
        const response = await axios.get(`http://localhost:9008/api/products/${id}`);
        setProduct(response.data);
      } catch (error) {
        console.error('Error fetching product:', error);
      }
    };
    fetchProduct();
  }, [id]);

  const handleAddToCart = (product) => {
    addToCart(product);
    setNotification('장바구니에 추가되었습니다!'); // 알림 메시지 설정
    setTimeout(() => {
      setNotification(''); // 3초 후 알림 메시지 지우기
    }, 3000);
  };

  if (!product) return <div>Loading...</div>;

  return (
    <div className="product-detail">
      <h2>상품 디테일 입니다.</h2>
      <h1>{product.productName}</h1>
      <div className="seller-info">
        <p>Seller: {product.seller}</p>
        <div className="add-to-cart">
          <button onClick={() => handleAddToCart(product)}>장바구니에 추가</button>
        </div>
      </div>
      {product.imagePath && (
        <div>
          <img src={product.imagePath} alt={product.productName} />
        </div>
      )}
      <div className="product-info">
        <p>{product.productDescription}</p>
      </div>
      <div className="buttons">
        <Link to="/payment">결제하기</Link>
        <Link to={`/edit/${product.productNumber}`}>Edit</Link>
      </div>
      {notification && <div className="notification">{notification}</div>}
      <Link to="/">홈으로 돌아가기</Link>
      <br />
      <Link to="/products">리스트로 돌아가기</Link>
    </div>
  );
};

export default ProductDetail;
