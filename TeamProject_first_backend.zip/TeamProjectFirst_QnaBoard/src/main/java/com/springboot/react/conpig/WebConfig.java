package com.springboot.react.conpig;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

// 백엔드 애플리케이션에 CORS 설정을 추가해야 합니다.
// Spring Boot에서는 WebMvcConfigurer를 구현하거나 @CrossOrigin 어노테이션을 사용하여
// 특정 엔드포인트 또는 전역에서 CORS를 허용할 수 있습니다.
// 예시: 전역 CORS 설정 추가

@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**")
        		.allowedOrigins("*", "http://192.168.10.49:3000", "http://localhost:3000")
//                .allowedOrigins("http://현재PC IP 주소 입력:3000", "http://localhost:3000")
                .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS")
                .allowedHeaders("*")
                .allowCredentials(false);
    }
    
    // 정적 리소스 핸들링을 위한 설정 메서드 오버라이드
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        // "/react_images/**" 경로로 요청되는 리소스에 대한 처리 설정
        registry.addResourceHandler("/react_images/**")
                // 실제 파일 시스템의 경로와 매핑
                // 이 경로에 저장된 리소스 파일들을 웹에서 접근 가능하도록 설정
                .addResourceLocations("file:///C:/react_images/");
        registry.addResourceHandler("/downloadFile/**")
		.addResourceLocations("file:///C:/react_images/");
    }
}