package com.springboot.react.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name="pay_import")

public class Payment {
	@Id // 기본 키(primary key)임을 나타냄
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "payment_seq_gen") // 시퀀스를 사용하여 기본 키 값을 자동으로 생성
    @SequenceGenerator(name = "payment_seq_gen", sequenceName = "idx_seq", allocationSize = 1) // 시퀀스 제너레이터 설정, 시퀀스 이름과 할당 크기 설정
    private Long pay_id; // 결제 ID, 기본 키

    private String imp_uid; // 아임포트 결제 고유번호
    private String merchant_uid; // 가맹점 주문번호
    private int pay_amount; // 결제 금액
    private String apply_num; // 카드 승인번호
    private Date per_time; // 결제 시간
}
