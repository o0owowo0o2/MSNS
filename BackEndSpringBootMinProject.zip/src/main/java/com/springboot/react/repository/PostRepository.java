// 패키지 선언
package com.springboot.react.repository;

// 필요한 클래스 및 인터페이스 import
import com.springboot.react.entity.Post; // 게시글 엔티티 클래스
import org.springframework.data.jpa.repository.JpaRepository; // JPA 리포지토리

// PostRepository 인터페이스 정의, JpaRepository를 확장하여 사용
public interface PostRepository extends JpaRepository<Post, Long> {
    // JpaRepository에는 다양한 데이터베이스 CRUD 연산을 위한 메소드가 정의되어 있습니다.
    // 이 인터페이스는 Post 엔티티에 대한 데이터 접근을 관리하며, JpaRepository 인터페이스로부터 상속받은
    // 기본적인 CRUD 연산과 페이징, 정렬 기능을 사용할 수 있습니다.

    // JpaRepository<Post, Long> 파라미터 설명:
    // - Post: 리포지토리가 관리할 엔티티 타입
    // - Long: 엔티티의 ID 필드 타입

    // 이 인터페이스를 통해 Spring Data JPA는 런타임에 필요한 구현체를 자동으로 생성하므로
    // 개발자는 복잡한 SQL 쿼리 없이 데이터베이스를 편리하게 다룰 수 있습니다.
}
