package com.springboot.react.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.springboot.react.entity.Payment;

public interface PaymentRepository extends JpaRepository<Payment, Long>{

}
