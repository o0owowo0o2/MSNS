// 패키지 선언
package com.springboot.react.service.impl;

// 필요한 클래스 및 인터페이스 import
import com.springboot.react.entity.Post; // 게시글 엔티티 클래스
import com.springboot.react.repository.PostRepository; // 게시글 데이터 접근 리포지토리
import com.springboot.react.service.PostService; // 게시글 서비스 인터페이스
import org.springframework.beans.factory.annotation.Autowired; // Spring의 의존성 주입 어노테이션
import org.springframework.stereotype.Service; // 서비스 계층을 나타내는 어노테이션
import org.springframework.transaction.annotation.Transactional; // 트랜잭션 관리 어노테이션

import java.util.List;
import java.util.Optional; // Java의 Optional 클래스 사용

// 클래스 선언 및 어노테이션
@Service // 이 클래스를 스프링 컴포넌트로 등록하며, 서비스 계층임을 나타냄
public class PostServiceImpl implements PostService { // PostService 인터페이스 구현

    // PostRepository 타입의 객체를 필드로 선언
    private final PostRepository postRepository;

    // 생성자를 통한 PostRepository 의존성 주입
    @Autowired
    public PostServiceImpl(PostRepository postRepository) {
        this.postRepository = postRepository; // 주입된 리포지토리 객체를 필드에 할당
    }

    // 게시글 저장 메소드 구현
    @Override
    @Transactional // 메소드를 트랜잭션으로 처리
    public Post savePost(Post post) {
        return postRepository.save(post); // 리포지토리의 save 메소드를 호출하여 게시글 저장
    }

    // ID를 통한 게시글 조회 메소드 구현
    @Override
    public Optional<Post> findPostById(Long id) {
        return postRepository.findById(id); // 리포지토리의 findById 메소드를 호출하여 ID로 게시글 조회
    }
    
    // 게시글 삭제 메소드 구현
    @Override
    @Transactional // 메소드를 트랜잭션으로 처리
    public void deletePost(Long id) {
        postRepository.deleteById(id); // 리포지토리의 deleteById 메소드를 호출하여 ID로 게시글 삭제
    }

	@Override
	public List<Post> findAll() {
		return postRepository.findAll();
	}
    
}
