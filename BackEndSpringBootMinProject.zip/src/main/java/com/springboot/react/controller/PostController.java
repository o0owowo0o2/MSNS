// Spring Boot와 React를 연동한 게시글 관리 웹 어플리케이션의 컨트롤러 정의
package com.springboot.react.controller;

// 필요한 클래스 및 인터페이스 import
import com.springboot.react.entity.Post;// 게시글 정보 엔티티
import com.springboot.react.service.PostService; // 게시글 서비스 인터페이스
import org.springframework.beans.factory.annotation.Autowired; // 자동 의존성 주입
import org.springframework.http.ResponseEntity; // HTTP 응답 엔티티
import org.springframework.web.bind.annotation.*; // RESTful 웹 서비스 어노테이션
import org.springframework.web.multipart.MultipartFile; // 파일 업로드 처리
import org.springframework.web.servlet.support.ServletUriComponentsBuilder; // URI 생성 도구
import com.fasterxml.jackson.databind.ObjectMapper; // JSON 객체 매핑

import java.io.IOException; // 예외 처리
import java.nio.file.*; // 파일 시스템 관리
import java.util.List;
import java.util.Optional;

// 클래스 선언 및 REST 컨트롤러 어노테이션, 기본 경로 설정
@RestController
@RequestMapping("/api/posts")
public class PostController {

    // 자동으로 PostService 의존성 주입
    @Autowired
    private PostService postService;

    
    // 이미지 파일 저장 경로 설정
    private final Path rootLocation = Paths.get("C:/react_images");

    // 이미지 업로드 및 게시글 등록을 위한 API
    @PostMapping("/upload")
    public ResponseEntity<?> uploadImage(@RequestParam("image") MultipartFile file,
                                         @RequestParam("post") String postStr) throws IOException {
        ObjectMapper objectMapper = new ObjectMapper(); // JSON 문자열을 Post 객체로 변환
        Post post = objectMapper.readValue(postStr, Post.class); // Post 데이터 매핑

        String fileName = file.getOriginalFilename(); // 업로드된 파일 이름 추출
        // 파일을 지정된 경로에 저장
        Files.copy(file.getInputStream(), this.rootLocation.resolve(fileName), StandardCopyOption.REPLACE_EXISTING);        

        // 파일 다운로드 URI 생성
        String fileDownloadUri = ServletUriComponentsBuilder.fromCurrentContextPath()
                .path("/downloadFile/")
                .path(fileName)
                .toUriString();
        post.setImagePath(fileDownloadUri); // 파일 경로를 Post 객체에 설정

        Post savedPost = postService.savePost(post); // Post 객체 저장 및 반환

        return ResponseEntity.ok("게시글이 등록되었습니다. ID: " + savedPost.getBoardNumber()); // 응답 반환
    }
    
    @GetMapping // 모든 게시글 조회
    public List<Post> getAllPosts() {
        return postService.findAll();
    }
    
    // 특정 ID로 게시글 조회 API
    @GetMapping("/{id}")
    public ResponseEntity<Post> getPostById(@PathVariable Long id) {
        Optional<Post> post = postService.findPostById(id); // ID로 게시글 검색
        if (!post.isPresent()) { // 게시글이 존재하지 않을 경우
            return ResponseEntity.notFound().build(); // 404 Not Found 응답 반환
        }
        return ResponseEntity.ok(post.get()); // 게시글 반환
    }

    // 게시글 수정 API
    @PutMapping("/update/{id}")
    public ResponseEntity<?> updatePost(@PathVariable Long id, @RequestParam("image") MultipartFile file, @RequestParam("post") String postStr) throws IOException {
        ObjectMapper objectMapper = new ObjectMapper(); // JSON 매핑
        Post postToUpdate = objectMapper.readValue(postStr, Post.class); // 수정할 Post 객체

        // 기존 게시글 조회
        Post existingPost = postService.findPostById(id).orElseThrow(() -> new RuntimeException("Post not found with id " + id));

        String fileName = file.getOriginalFilename(); // 파일 이름 추출
        Files.copy(file.getInputStream(), this.rootLocation.resolve(fileName), StandardCopyOption.REPLACE_EXISTING); // 파일 저장

        // 파일 다운로드 URI 설정
        String fileDownloadUri = ServletUriComponentsBuilder.fromCurrentContextPath()
                .path("/downloadFile/")
                .path(fileName)
                .toUriString();

        // Post 정보 업데이트
        existingPost.setBoardTitle(postToUpdate.getBoardTitle());
        existingPost.setBoardContents(postToUpdate.getBoardContents());
        existingPost.setImagePath(fileDownloadUri);

        Post updatedPost = postService.savePost(existingPost); // 수정된 게시글 저장 및 반환

        return ResponseEntity.ok("게시글이 수정되었습니다. ID: " + updatedPost.getBoardNumber()); // 응답 반환
    }
    
    // 게시글 삭제 API
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deletePost(@PathVariable Long id) {
        return postService.findPostById(id).map(post -> {
            if (post.getImagePath() != null && !post.getImagePath().isEmpty()) { // 이미지 파일이 있을 경우 파일 이름 추출
                String fileName = post.getImagePath().substring(post.getImagePath().lastIndexOf('/') + 1);
                Path path = Paths.get(rootLocation.toString(), fileName);
                try {
                    Files.deleteIfExists(path); // 파일 삭제 시도
                } catch (IOException e) {
                    e.printStackTrace(); // 예외 처리
                }
            }
            postService.deletePost(id); // 게시글 데이터베이스에서 삭제
            return ResponseEntity.ok().body("게시글이 삭제되었습니다."); // 응답 반환
        }).orElseGet(() -> ResponseEntity.notFound().build()); // 게시글이 존재하지 않을 경우 404 응답 반환
    }
}
