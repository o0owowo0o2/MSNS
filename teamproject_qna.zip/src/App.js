import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.css';
import Landing from './components/Landing';
import Main from './components/Main';
import QnaPostList from './components/QnaPostList';
import QnaPostDetail from './components/QnaPostDetail';
import QnaPostEdit from './components/QnaPostEdit';
import Location from './components/Location';
import Qna from './components/Qna';
import Header from './components/Header';
import Footer from './components/Footer';
import CreateQnaPost from './components/CreateQnaPost';
import './css/component.css';
import CommunityList from './components/CommunityList';
import CommunityDetail from './components/CommunityDetail';
import CommunityEdit from './components/CommunityEdit';
import CreateCommunity from './components/CreateCommunity';
import CreateContect from './components/CreateContect';
import ProductList from './components/ProductList';
import ProductDetail from './components/ProductDetail';
import ProductFormEdit from './components/ProductFormEdit';
import ProductForm from './components/ProductFormCreate';
import Payment from './components/Payment';
import CartPage from './components/CartPage';
import { CartProvider } from './components/CartContext';
import AddrDaumKakao02 from './components/AddrDaumKakao02';
import CreatePost from './components/CreatePost';
import PaymentSuccess from './components/PaymentSuccess';


function App() {
  return (
    <CartProvider>
    <div className='app'>
      <Router>
        <Header />
        <Switch>
          <Route path="/" component={Landing} exact={true} />
          <Route path="/main" component={Main} exact={true} />
          <Route path="/qna" component={Qna} />
          <Route path="/location" component={Location} />
          <Route path="/qnaPostList" component={QnaPostList} />
          <Route path="/createQnaPost" component={CreateQnaPost} />
          <Route path="/posts/:boardNumber" component={QnaPostDetail} />
          <Route path="/edit/:boardNumber" component={QnaPostEdit} />
          <Route path="/커뮤니티" component={CommunityList} />
          <Route path="/communitys/:boardNumber" component={CommunityDetail} />
          <Route path="/edit/:boardNumber" component={CommunityEdit} />
          <Route path="/community_register" component={CreateCommunity} exact={true} />
          <Route path="/문의하기" component={CreateContect} /> 
          <Route path="/SHOP" component={ProductList} />
          <Route path="/products/:id" component={ProductDetail} />
              <Route path="/add" component={ProductForm} />
              <Route path="/edit/:id" component={ProductFormEdit} />
              <Route path="/payment" component={Payment} />
              <Route path="/장바구니" component={CartPage} />
              <Route path="/paymentSuccess" component={PaymentSuccess} />
              <Route path="/create" component={CreatePost} />
              <Route path="/daum_kakao_addr_02" component={AddrDaumKakao02} />
        </Switch>
        <Footer />
      </Router>
    </div>
    </CartProvider>
  );
}

export default App;
