import React from 'react';
import { Link } from 'react-router-dom';
import '../css/PaymentSuccess.css';  // CSS 파일을 import합니다.

function PaymentSuccess() {
  return (
    <div className="payment-success-container">
      <h1>결제완료</h1>
      <p>결제 처리가 제대로 되었습니다.</p>
      <br />
      <Link to="/">[처음으로]</Link>
    </div>
  );
}

export default PaymentSuccess;
