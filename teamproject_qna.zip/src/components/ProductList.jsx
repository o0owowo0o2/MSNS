import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import '../css/ProductList.css';

const ProductList = () => {
  const [products, setProducts] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const productsPerPage = 5;

  const fetchProducts = async () => {
    const response = await axios.get('http://localhost:9008/api/products');
    setProducts(response.data);
  };

  const handleDeleteProduct = async (productNumber) => {
    await axios.delete(`http://localhost:9008/api/products/${productNumber}`);
    setProducts(products.filter((p) => p.productNumber !== productNumber));
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  const handleClick = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  const indexOfLastProduct = currentPage * productsPerPage;
  const indexOfFirstProduct = indexOfLastProduct - productsPerPage;
  const currentProducts = products.slice(indexOfFirstProduct, indexOfLastProduct);

  const pageNumbers = [];
  for (let i = 1; i <= Math.ceil(products.length / productsPerPage); i++) {
    pageNumbers.push(i);
  }

  // 빈 div를 추가하여 상품 목록을 5의 배수로 맞추기
  const totalSlots = Math.ceil(currentProducts.length / 5) * 5;
  const emptySlots = totalSlots - currentProducts.length;

  return (
    <div className="product-list-container">
      <h1>상품 목록</h1>
      <div className='add'><Link to="/add">상품 추가</Link></div>
     
      <div className="product-grid">
        {currentProducts.map((product) => (
          <div key={product.productNumber} className="product-item">
            <Link to={`/products/${product.productNumber}`} className="product-name-link">
              <img src={product.imagePath} alt={product.productName} className="product-image" />
              <br /><br />
              <h3>{product.productName}</h3>
            </Link>
            
            <h2>{product.seller}</h2>
            <br />
            <Link to={`/edit/${product.productNumber}`}>수정</Link> {/* 수정 링크 */}
            <div className='delete' onClick={() => handleDeleteProduct(product.productNumber)}>삭제</div>
          </div>
        ))}
        {Array.from({ length: emptySlots }, (_, index) => (
          <div key={`empty-${index}`} className="product-item empty"></div>
        ))}
      </div>
      <div className="pagination">
        {pageNumbers.map((number) => (
          <button key={number} onClick={() => handleClick(number)} className={currentPage === number ? 'active' : ''}>
            {number}
          </button>
        ))}
      </div>
    </div>
  );
};

export default ProductList;
