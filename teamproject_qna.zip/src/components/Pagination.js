// React 라이브러리를 임포트합니다.
import React from 'react';

// Pagination 함수형 컴포넌트를 선언합니다. 
// 이 컴포넌트는 현재 페이지 번호(currentPage), 전체 페이지 수(totalPages), 
// 그리고 페이지 번호를 변경할 때 호출되는 함수(paginate)를 props로 받습니다.
const Pagination = ({ currentPage, totalPages, paginate }) => {
    // JSX를 반환합니다. 이 구조는 페이징 버튼을 담고 있습니다.
    return (
        <div>
            {/* "처음" 버튼을 클릭하면 paginate 함수가 호출되어 첫 번째 페이지로 이동합니다.
              currentPage가 1 이하일 경우 이 버튼은 비활성화됩니다.  */}
            <button onClick={() => paginate(1)} disabled={currentPage <= 1}>
                처음
            </button>
            {/* "이전" 버튼을 클릭하면 paginate 함수가 호출되어 이전 페이지로 이동합니다.
              currentPage가 1 이하일 경우 이 버튼은 비활성화됩니다. */}
            <button onClick={() => paginate(currentPage - 1)} disabled={currentPage <= 1}>
                이전
            </button>
            {/* 현재 페이지 번호와 전체 페이지 수를 표시합니다. */}
            <span>페이지 {currentPage} / {totalPages}</span>
            {/* "다음" 버튼을 클릭하면 paginate 함수가 호출되어 다음 페이지로 이동합니다.
              currentPage가 totalPages 이상일 경우 이 버튼은 비활성화됩니다.  */}
            <button onClick={() => paginate(currentPage + 1)} disabled={currentPage >= totalPages}>
                다음
            </button>
            {/* "마지막" 버튼을 클릭하면 paginate 함수가 호출되어 마지막 페이지로 이동합니다.
               currentPage가 totalPages 이상일 경우 이 버튼은 비활성화됩니다. */}
            <button onClick={() => paginate(totalPages)} disabled={currentPage >= totalPages}>
                마지막
            </button>
        </div>
    );
};

// Pagination 컴포넌트를 다른 컴포넌트에서 임포트하여 사용할 수 있도록 export 합니다.
export default Pagination;
