import React from 'react';
import { Container } from 'react-bootstrap';
import { Link } from 'react-router-dom/cjs/react-router-dom.min';

function Main() {
    return (
            <Container>
        <div className='divcss'>
                <Link to='/members/:memberNumber'>내 정보</Link><br />
                <Link to="/noticeList">공지사항</Link><br />
                <Link to="/DonationInformation">유기견 후원</Link><br />
                <Link to="/deleteRegister">회원탈퇴</Link><br />
            
        </div>
        </Container>
    );
}

export default Main;