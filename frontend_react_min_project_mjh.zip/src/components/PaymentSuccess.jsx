import React from 'react';

function PaymentSuccess() {
    return (
        <div>
            <h2>결제성공 페이지</h2>
            <p>결제 처리가 제대로 되었습니다.</p>
            <Link to="/">[처음으로]</Link>
        </div>
    );
}

export default PaymentSuccess;