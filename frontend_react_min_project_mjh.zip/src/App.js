import React from 'react';
import {BrowserRouter as Router, Route, Switch} from 'react-router-dom';
import Register from './components/Register';
import Main from './components/Main';
import MyPage from './components/MyPage';
import ModifyRegister from './components/ModifyRegister';
import LoginMain from './components/LoginMain';
import DonationInformation from './components/DonationInformation';
import EditNotice from './components/EditNotice';
import DeleteNotice from './components/DeleteNotice';
import Payment from './components/Payment';
import Address from './components/Address';
import Header from './components/Header';
import Footer from './components/Footer';
import './css/component.css';
import 'bootstrap/dist/css/bootstrap.css';
import CreateNotice from './components/CreateNotice';
import NoticeDetail from './components/NoticeDetail';
import NoticeList from './components/NoticeList';
import DeleteRegister from './components/DeleteRegister';
import MemberMain from './components/MemberMain';

function App() {
  return (
    <div>
      <Router>
       <Header />
        <Switch>
        <Route path="/" component={Main} exact={true}/>
        <Route path="/register" component={Register} />
        <Route path="/loginMain" component={LoginMain} />
        <Route path="/members/:memberNumber" component={MyPage} />
        <Route path="/modifyRegister" component={ModifyRegister} />
        <Route path="/deleteRegister" component={DeleteRegister} />
        <Route path="/address" component={Address} />
        <Route path="/noticeList" component={NoticeList} />
        <Route path="/createNotice" component={CreateNotice} />
        <Route path="/notices/:noticeNumber" component={NoticeDetail} />
        <Route path='/edit/:noticeNumber' component={EditNotice} />
        <Route path='/delete' component={DeleteNotice} />
        <Route path="/donationInformation" component={DonationInformation} />
        <Route path='/payment' component={Payment} />
        <Route path='/memberMain' component={MemberMain} />
        <Route path='/loginMain' component={LoginMain} />


        </Switch>
        <Footer />
      </Router>     
    </div>
  );
}

export default App;